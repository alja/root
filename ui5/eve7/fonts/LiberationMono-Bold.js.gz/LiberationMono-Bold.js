{
  "ix": 0.0117188, 
  "iy": 0.0136364, 
  "row_height": 0.1, 
  "aspect": 1.16364, 
  "ascent": 0.0534483, 
  "descent": 0.019279, 
  "line_gap": 0, 
  "cap_height": 0.0422884, 
  "x_height": 0.0339185, 
  "space_advance": 0.0331088, 

  "chars": { 
  "\u0021": {
    "codepoint": 33,
    "rect": [0, 0.9, 0.0313578, 1],
    "bearing_x": 0.0126078,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0022": {
    "codepoint": 34,
    "rect": [0.0322266, 0.9, 0.075357, 1],
    "bearing_x": 0.00673491,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0023": {
    "codepoint": 35,
    "rect": [0.0761719, 0.9, 0.129485, 1],
    "bearing_x": 0.00158944,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0024": {
    "codepoint": 36,
    "rect": [0.129883, 0.9, 0.182496, 1],
    "bearing_x": 0.00185884,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0025": {
    "codepoint": 37,
    "rect": [0.182617, 0.9, 0.23919, 1],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0026": {
    "codepoint": 38,
    "rect": [0.239258, 0.9, 0.294942, 1],
    "bearing_x": 0.000646552,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0027": {
    "codepoint": 39,
    "rect": [0.295898, 0.9, 0.32669, 1],
    "bearing_x": 0.0128772,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0028": {
    "codepoint": 40,
    "rect": [0.327148, 0.9, 0.366157, 1],
    "bearing_x": 0.00926724,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0029": {
    "codepoint": 41,
    "rect": [0.366211, 0.9, 0.40522, 1],
    "bearing_x": 0.00827047,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002a": {
    "codepoint": 42,
    "rect": [0.405273, 0.9, 0.449966, 1],
    "bearing_x": 0.00592672,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002b": {
    "codepoint": 43,
    "rect": [0.450195, 0.9, 0.5013, 1],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002c": {
    "codepoint": 44,
    "rect": [0.501953, 0.9, 0.538429, 1],
    "bearing_x": 0.00695043,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002d": {
    "codepoint": 45,
    "rect": [0.539062, 0.9, 0.578125, 1],
    "bearing_x": 0.00872845,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002e": {
    "codepoint": 46,
    "rect": [0.578125, 0.9, 0.609348, 1],
    "bearing_x": 0.0126616,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002f": {
    "codepoint": 47,
    "rect": [0.609375, 0.9, 0.661072, 1],
    "bearing_x": 0.00239763,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0030": {
    "codepoint": 48,
    "rect": [0.661133, 0.9, 0.711348, 1],
    "bearing_x": 0.00315194,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0031": {
    "codepoint": 49,
    "rect": [0.711914, 0.9, 0.762399, 1],
    "bearing_x": 0.00371767,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0032": {
    "codepoint": 50,
    "rect": [0.762695, 0.9, 0.812695, 1],
    "bearing_x": 0.00331358,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0033": {
    "codepoint": 51,
    "rect": [0.813477, 0.9, 0.864716, 1],
    "bearing_x": 0.00250539,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0034": {
    "codepoint": 52,
    "rect": [0.865234, 0.9, 0.918225, 1],
    "bearing_x": 0.00191272,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0035": {
    "codepoint": 53,
    "rect": [0.918945, 0.9, 0.969834, 1],
    "bearing_x": 0.00280172,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0036": {
    "codepoint": 54,
    "rect": [0, 0.8, 0.0501078, 0.9],
    "bearing_x": 0.00336746,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0037": {
    "codepoint": 55,
    "rect": [0.0507812, 0.8, 0.100108, 0.9],
    "bearing_x": 0.00352909,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0038": {
    "codepoint": 56,
    "rect": [0.100586, 0.8, 0.151259, 0.9],
    "bearing_x": 0.00293642,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0039": {
    "codepoint": 57,
    "rect": [0.151367, 0.8, 0.201529, 0.9],
    "bearing_x": 0.00307112,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u003a": {
    "codepoint": 58,
    "rect": [0.202148, 0.8, 0.233371, 0.9],
    "bearing_x": 0.0126616,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003b": {
    "codepoint": 59,
    "rect": [0.233398, 0.8, 0.269875, 0.9],
    "bearing_x": 0.00878233,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003c": {
    "codepoint": 60,
    "rect": [0.270508, 0.8, 0.321612, 0.9],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003d": {
    "codepoint": 61,
    "rect": [0.322266, 0.8, 0.37337, 0.9],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003e": {
    "codepoint": 62,
    "rect": [0.374023, 0.8, 0.425128, 0.9],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003f": {
    "codepoint": 63,
    "rect": [0.425781, 0.8, 0.477209, 0.9],
    "bearing_x": 0.00199353,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0040": {
    "codepoint": 64,
    "rect": [0.477539, 0.8, 0.531822, 0.9],
    "bearing_x": 0.00118534,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0041": {
    "codepoint": 65,
    "rect": [0.532227, 0.8, 0.588773, 0.9],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0042": {
    "codepoint": 66,
    "rect": [0.588867, 0.8, 0.640564, 0.9],
    "bearing_x": 0.00369073,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0043": {
    "codepoint": 67,
    "rect": [0.640625, 0.8, 0.693481, 0.9],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0044": {
    "codepoint": 68,
    "rect": [0.694336, 0.8, 0.74509, 0.9],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0045": {
    "codepoint": 69,
    "rect": [0.745117, 0.8, 0.795737, 0.9],
    "bearing_x": 0.00369073,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0046": {
    "codepoint": 70,
    "rect": [0.795898, 0.8, 0.844632, 0.9],
    "bearing_x": 0.00449892,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0047": {
    "codepoint": 71,
    "rect": [0.844727, 0.8, 0.896397, 0.9],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0048": {
    "codepoint": 72,
    "rect": [0.896484, 0.8, 0.945595, 0.9],
    "bearing_x": 0.00371767,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0049": {
    "codepoint": 73,
    "rect": [0.946289, 0.8, 0.994403, 0.9],
    "bearing_x": 0.00422953,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004a": {
    "codepoint": 74,
    "rect": [0, 0.7, 0.0481412, 0.8],
    "bearing_x": 0.00274784,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004b": {
    "codepoint": 75,
    "rect": [0.0488281, 0.7, 0.101711, 0.8],
    "bearing_x": 0.00366379,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004c": {
    "codepoint": 76,
    "rect": [0.102539, 0.7, 0.150519, 0.8],
    "bearing_x": 0.00568427,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004d": {
    "codepoint": 77,
    "rect": [0.151367, 0.7, 0.202579, 0.8],
    "bearing_x": 0.00266703,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004e": {
    "codepoint": 78,
    "rect": [0.203125, 0.7, 0.252398, 0.8],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004f": {
    "codepoint": 79,
    "rect": [0.25293, 0.7, 0.305597, 0.8],
    "bearing_x": 0.00193966,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0050": {
    "codepoint": 80,
    "rect": [0.305664, 0.7, 0.356203, 0.8],
    "bearing_x": 0.00366379,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0051": {
    "codepoint": 81,
    "rect": [0.356445, 0.7, 0.409409, 0.8],
    "bearing_x": 0.00193966,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0052": {
    "codepoint": 82,
    "rect": [0.410156, 0.7, 0.462958, 0.8],
    "bearing_x": 0.00369073,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0053": {
    "codepoint": 83,
    "rect": [0.463867, 0.7, 0.517666, 0.8],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0054": {
    "codepoint": 84,
    "rect": [0.518555, 0.7, 0.571814, 0.8],
    "bearing_x": 0.00164332,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0055": {
    "codepoint": 85,
    "rect": [0.572266, 0.7, 0.621862, 0.8],
    "bearing_x": 0.00347522,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0056": {
    "codepoint": 86,
    "rect": [0.62207, 0.7, 0.678482, 0.8],
    "bearing_x": 8.0819e-05,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0057": {
    "codepoint": 87,
    "rect": [0.678711, 0.7, 0.73523, 0.8],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0058": {
    "codepoint": 88,
    "rect": [0.735352, 0.7, 0.791898, 0.8],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0059": {
    "codepoint": 89,
    "rect": [0.791992, 0.7, 0.84835, 0.8],
    "bearing_x": 8.0819e-05,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u005a": {
    "codepoint": 90,
    "rect": [0.848633, 0.7, 0.900384, 0.8],
    "bearing_x": 0.00234375,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u005b": {
    "codepoint": 91,
    "rect": [0.900391, 0.7, 0.940046, 0.8],
    "bearing_x": 0.0100485,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005c": {
    "codepoint": 92,
    "rect": [0.94043, 0.7, 0.992127, 0.8],
    "bearing_x": 0.00245151,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005d": {
    "codepoint": 93,
    "rect": [0, 0.6, 0.0396552, 0.7],
    "bearing_x": 0.00684267,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005e": {
    "codepoint": 94,
    "rect": [0.0400391, 0.6, 0.0932718, 0.7],
    "bearing_x": 0.00121228,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005f": {
    "codepoint": 95,
    "rect": [0.09375, 0.6, 0.150539, 0.7],
    "bearing_x": -0.000134698,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0060": {
    "codepoint": 96,
    "rect": [0.151367, 0.6, 0.188544, 0.7],
    "bearing_x": 0.00934806,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0061": {
    "codepoint": 97,
    "rect": [0.189453, 0.6, 0.24177, 0.7],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0062": {
    "codepoint": 98,
    "rect": [0.242188, 0.6, 0.292349, 0.7],
    "bearing_x": 0.00377155,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0063": {
    "codepoint": 99,
    "rect": [0.292969, 0.6, 0.343319, 0.7],
    "bearing_x": 0.00296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0064": {
    "codepoint": 100,
    "rect": [0.34375, 0.6, 0.393912, 0.7],
    "bearing_x": 0.00261315,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0065": {
    "codepoint": 101,
    "rect": [0.394531, 0.6, 0.44569, 0.7],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0066": {
    "codepoint": 102,
    "rect": [0.446289, 0.6, 0.496801, 0.7],
    "bearing_x": 0.00315194,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0067": {
    "codepoint": 103,
    "rect": [0.49707, 0.6, 0.547178, 0.7],
    "bearing_x": 0.00334052,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0068": {
    "codepoint": 104,
    "rect": [0.547852, 0.6, 0.597178, 0.7],
    "bearing_x": 0.00385237,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0069": {
    "codepoint": 105,
    "rect": [0.597656, 0.6, 0.648815, 0.7],
    "bearing_x": 0.00317888,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006a": {
    "codepoint": 106,
    "rect": [0.649414, 0.6, 0.692975, 0.7],
    "bearing_x": 0.00315194,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006b": {
    "codepoint": 107,
    "rect": [0.693359, 0.6, 0.743683, 0.7],
    "bearing_x": 0.00466056,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006c": {
    "codepoint": 108,
    "rect": [0.744141, 0.6, 0.79247, 0.7],
    "bearing_x": 0.00600754,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006d": {
    "codepoint": 109,
    "rect": [0.792969, 0.6, 0.845636, 0.7],
    "bearing_x": 0.00185884,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006e": {
    "codepoint": 110,
    "rect": [0.845703, 0.6, 0.895245, 0.7],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006f": {
    "codepoint": 111,
    "rect": [0.895508, 0.6, 0.947097, 0.7],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0070": {
    "codepoint": 112,
    "rect": [0.947266, 0.6, 0.997427, 0.7],
    "bearing_x": 0.00377155,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0071": {
    "codepoint": 113,
    "rect": [0, 0.5, 0.0501616, 0.6],
    "bearing_x": 0.00261315,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0072": {
    "codepoint": 114,
    "rect": [0.0507812, 0.5, 0.0980065, 0.6],
    "bearing_x": 0.00533405,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0073": {
    "codepoint": 115,
    "rect": [0.0986328, 0.5, 0.148552, 0.6],
    "bearing_x": 0.0032597,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0074": {
    "codepoint": 116,
    "rect": [0.149414, 0.5, 0.196397, 0.6],
    "bearing_x": 0.00433728,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0075": {
    "codepoint": 117,
    "rect": [0.197266, 0.5, 0.246269, 0.6],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0076": {
    "codepoint": 118,
    "rect": [0.24707, 0.5, 0.301812, 0.6],
    "bearing_x": 0.000835129,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0077": {
    "codepoint": 119,
    "rect": [0.302734, 0.5, 0.358688, 0.6],
    "bearing_x": 0.000296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0078": {
    "codepoint": 120,
    "rect": [0.359375, 0.5, 0.413254, 0.6],
    "bearing_x": 0.00132004,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0079": {
    "codepoint": 121,
    "rect": [0.414062, 0.5, 0.468534, 0.6],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u007a": {
    "codepoint": 122,
    "rect": [0.46875, 0.5, 0.517484, 0.6],
    "bearing_x": 0.00371767,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u007b": {
    "codepoint": 123,
    "rect": [0.517578, 0.5, 0.563941, 0.6],
    "bearing_x": 0.00522629,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007c": {
    "codepoint": 124,
    "rect": [0.564453, 0.5, 0.594949, 0.6],
    "bearing_x": 0.0130119,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007d": {
    "codepoint": 125,
    "rect": [0.595703, 0.5, 0.642066, 0.6],
    "bearing_x": 0.0049569,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007e": {
    "codepoint": 126,
    "rect": [0.642578, 0.5, 0.693979, 0.6],
    "bearing_x": 0.00255927,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u00e0": {
    "codepoint": 224,
    "rect": [0.694336, 0.5, 0.746653, 0.6],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e1": {
    "codepoint": 225,
    "rect": [0.74707, 0.5, 0.799387, 0.6],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e2": {
    "codepoint": 226,
    "rect": [0.799805, 0.5, 0.852121, 0.6],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e3": {
    "codepoint": 227,
    "rect": [0.852539, 0.5, 0.904856, 0.6],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e4": {
    "codepoint": 228,
    "rect": [0.905273, 0.5, 0.95759, 0.6],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e5": {
    "codepoint": 229,
    "rect": [0, 0.4, 0.0523168, 0.5],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e6": {
    "codepoint": 230,
    "rect": [0.0527344, 0.4, 0.108176, 0.5],
    "bearing_x": 0.000538793,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e7": {
    "codepoint": 231,
    "rect": [0.108398, 0.4, 0.158749, 0.5],
    "bearing_x": 0.00296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e8": {
    "codepoint": 232,
    "rect": [0.15918, 0.4, 0.210338, 0.5],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e9": {
    "codepoint": 233,
    "rect": [0.210938, 0.4, 0.262096, 0.5],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ea": {
    "codepoint": 234,
    "rect": [0.262695, 0.4, 0.313854, 0.5],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00eb": {
    "codepoint": 235,
    "rect": [0.314453, 0.4, 0.365612, 0.5],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ec": {
    "codepoint": 236,
    "rect": [0.366211, 0.4, 0.417369, 0.5],
    "bearing_x": 0.00317888,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ed": {
    "codepoint": 237,
    "rect": [0.417969, 0.4, 0.469127, 0.5],
    "bearing_x": 0.00317888,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ee": {
    "codepoint": 238,
    "rect": [0.469727, 0.4, 0.520885, 0.5],
    "bearing_x": 0.00317888,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ef": {
    "codepoint": 239,
    "rect": [0.521484, 0.4, 0.572643, 0.5],
    "bearing_x": 0.00317888,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f0": {
    "codepoint": 240,
    "rect": [0.573242, 0.4, 0.624993, 0.5],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f1": {
    "codepoint": 241,
    "rect": [0.625, 0.4, 0.674542, 0.5],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f2": {
    "codepoint": 242,
    "rect": [0.674805, 0.4, 0.726394, 0.5],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f3": {
    "codepoint": 243,
    "rect": [0.726562, 0.4, 0.778152, 0.5],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f4": {
    "codepoint": 244,
    "rect": [0.77832, 0.4, 0.82991, 0.5],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f5": {
    "codepoint": 245,
    "rect": [0.830078, 0.4, 0.881668, 0.5],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f6": {
    "codepoint": 246,
    "rect": [0.881836, 0.4, 0.933425, 0.5],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f7": {
    "codepoint": 247,
    "rect": [0.933594, 0.4, 0.984698, 0.5],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u00f8": {
    "codepoint": 248,
    "rect": [0, 0.3, 0.0515894, 0.4],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f9": {
    "codepoint": 249,
    "rect": [0.0517578, 0.3, 0.100761, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fa": {
    "codepoint": 250,
    "rect": [0.101562, 0.3, 0.150566, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fb": {
    "codepoint": 251,
    "rect": [0.151367, 0.3, 0.20037, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fc": {
    "codepoint": 252,
    "rect": [0.201172, 0.3, 0.250175, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u010c": {
    "codepoint": 268,
    "rect": [0.250977, 0.3, 0.303832, 0.4],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u010d": {
    "codepoint": 269,
    "rect": [0.304688, 0.3, 0.355038, 0.4],
    "bearing_x": 0.00296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0160": {
    "codepoint": 352,
    "rect": [0.355469, 0.3, 0.409267, 0.4],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0161": {
    "codepoint": 353,
    "rect": [0.410156, 0.3, 0.460075, 0.4],
    "bearing_x": 0.0032597,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u017d": {
    "codepoint": 381,
    "rect": [0.460938, 0.3, 0.512689, 0.4],
    "bearing_x": 0.00234375,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u017e": {
    "codepoint": 382,
    "rect": [0.512695, 0.3, 0.561429, 0.4],
    "bearing_x": 0.00371767,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0391": {
    "codepoint": 913,
    "rect": [0.561523, 0.3, 0.61807, 0.4],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0392": {
    "codepoint": 914,
    "rect": [0.618164, 0.3, 0.669861, 0.4],
    "bearing_x": 0.00369073,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0393": {
    "codepoint": 915,
    "rect": [0.669922, 0.3, 0.71941, 0.4],
    "bearing_x": 0.00476832,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0394": {
    "codepoint": 916,
    "rect": [0.719727, 0.3, 0.77533, 0.4],
    "bearing_x": 0.000484914,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0395": {
    "codepoint": 917,
    "rect": [0.775391, 0.3, 0.82601, 0.4],
    "bearing_x": 0.00369073,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0396": {
    "codepoint": 918,
    "rect": [0.826172, 0.3, 0.877923, 0.4],
    "bearing_x": 0.00234375,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0397": {
    "codepoint": 919,
    "rect": [0.87793, 0.3, 0.927041, 0.4],
    "bearing_x": 0.00371767,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0398": {
    "codepoint": 920,
    "rect": [0.927734, 0.3, 0.98094, 0.4],
    "bearing_x": 0.00167026,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0399": {
    "codepoint": 921,
    "rect": [0, 0.2, 0.0481142, 0.3],
    "bearing_x": 0.00422953,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039a": {
    "codepoint": 922,
    "rect": [0.0488281, 0.2, 0.101711, 0.3],
    "bearing_x": 0.00366379,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039b": {
    "codepoint": 923,
    "rect": [0.102539, 0.2, 0.158008, 0.3],
    "bearing_x": 0.000538793,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039c": {
    "codepoint": 924,
    "rect": [0.158203, 0.2, 0.209415, 0.3],
    "bearing_x": 0.00266703,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039d": {
    "codepoint": 925,
    "rect": [0.209961, 0.2, 0.259234, 0.3],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039e": {
    "codepoint": 926,
    "rect": [0.259766, 0.2, 0.310116, 0.3],
    "bearing_x": 0.00309806,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039f": {
    "codepoint": 927,
    "rect": [0.310547, 0.2, 0.363214, 0.3],
    "bearing_x": 0.00193966,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a0": {
    "codepoint": 928,
    "rect": [0.363281, 0.2, 0.412392, 0.3],
    "bearing_x": 0.00371767,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a1": {
    "codepoint": 929,
    "rect": [0.413086, 0.2, 0.463625, 0.3],
    "bearing_x": 0.00366379,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a3": {
    "codepoint": 931,
    "rect": [0.463867, 0.2, 0.51578, 0.3],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a4": {
    "codepoint": 932,
    "rect": [0.516602, 0.2, 0.569861, 0.3],
    "bearing_x": 0.00164332,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a5": {
    "codepoint": 933,
    "rect": [0.570312, 0.2, 0.62667, 0.3],
    "bearing_x": 8.0819e-05,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a6": {
    "codepoint": 934,
    "rect": [0.626953, 0.2, 0.683042, 0.3],
    "bearing_x": 0.000242457,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a7": {
    "codepoint": 935,
    "rect": [0.683594, 0.2, 0.74014, 0.3],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a8": {
    "codepoint": 936,
    "rect": [0.740234, 0.2, 0.794302, 0.3],
    "bearing_x": 0.00123922,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a9": {
    "codepoint": 937,
    "rect": [0.794922, 0.2, 0.848747, 0.3],
    "bearing_x": 0.00134698,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03b1": {
    "codepoint": 945,
    "rect": [0.849609, 0.2, 0.904243, 0.3],
    "bearing_x": 0.00188578,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b2": {
    "codepoint": 946,
    "rect": [0.904297, 0.2, 0.955455, 0.3],
    "bearing_x": 0.00382543,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b3": {
    "codepoint": 947,
    "rect": [0, 0.1, 0.0544989, 0.2],
    "bearing_x": 0.000969828,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b4": {
    "codepoint": 948,
    "rect": [0.0546875, 0.1, 0.10695, 0.2],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b5": {
    "codepoint": 949,
    "rect": [0.107422, 0.1, 0.157853, 0.2],
    "bearing_x": 0.00352909,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b6": {
    "codepoint": 950,
    "rect": [0.158203, 0.1, 0.207584, 0.2],
    "bearing_x": 0.00452586,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b7": {
    "codepoint": 951,
    "rect": [0.208008, 0.1, 0.258304, 0.2],
    "bearing_x": 0.0029903,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b8": {
    "codepoint": 952,
    "rect": [0.258789, 0.1, 0.308277, 0.2],
    "bearing_x": 0.00350216,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b9": {
    "codepoint": 953,
    "rect": [0.308594, 0.1, 0.359941, 0.2],
    "bearing_x": 0.00320582,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03ba": {
    "codepoint": 954,
    "rect": [0.360352, 0.1, 0.410675, 0.2],
    "bearing_x": 0.00466056,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bb": {
    "codepoint": 955,
    "rect": [0.411133, 0.1, 0.464177, 0.2],
    "bearing_x": 0.00180496,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bc": {
    "codepoint": 956,
    "rect": [0.464844, 0.1, 0.514494, 0.2],
    "bearing_x": 0.00360991,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bd": {
    "codepoint": 957,
    "rect": [0.514648, 0.1, 0.566642, 0.2],
    "bearing_x": 0.00107759,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03be": {
    "codepoint": 958,
    "rect": [0.567383, 0.1, 0.617086, 0.2],
    "bearing_x": 0.00420259,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bf": {
    "codepoint": 959,
    "rect": [0.617188, 0.1, 0.668777, 0.2],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c0": {
    "codepoint": 960,
    "rect": [0.668945, 0.1, 0.723875, 0.2],
    "bearing_x": 0.000727371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c1": {
    "codepoint": 961,
    "rect": [0.724609, 0.1, 0.775013, 0.2],
    "bearing_x": 0.00344828,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c2": {
    "codepoint": 962,
    "rect": [0.775391, 0.1, 0.824475, 0.2],
    "bearing_x": 0.0042834,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c3": {
    "codepoint": 963,
    "rect": [0.825195, 0.1, 0.879371, 0.2],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c4": {
    "codepoint": 964,
    "rect": [0.879883, 0.1, 0.928697, 0.2],
    "bearing_x": 0.00344828,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c5": {
    "codepoint": 965,
    "rect": [0.928711, 0.1, 0.978576, 0.2],
    "bearing_x": 0.00382543,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c6": {
    "codepoint": 966,
    "rect": [0, 0, 0.0543103, 0.1],
    "bearing_x": 0.00110453,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c7": {
    "codepoint": 967,
    "rect": [0.0546875, 0, 0.109267, 0.1],
    "bearing_x": 0.00110453,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c8": {
    "codepoint": 968,
    "rect": [0.109375, 0, 0.161988, 0.1],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c9": {
    "codepoint": 969,
    "rect": [0.162109, 0, 0.216177, 0.1],
    "bearing_x": 0.00126616,
    "advance_x": 0.0331088,
    "flags": 1
  }
  },
  "kern": {
  }
}
