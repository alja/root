{
  "ix": 0.0117188, 
  "iy": 0.0136364, 
  "row_height": 0.1, 
  "aspect": 1.16364, 
  "ascent": 0.0534483, 
  "descent": 0.019279, 
  "line_gap": 0, 
  "cap_height": 0.0422884, 
  "x_height": 0.0339185, 
  "space_advance": 0.0331088, 

  "chars": { 
  "\u0021": {
    "codepoint": 33,
    "rect": [0, 0.9, 0.0358297, 1],
    "bearing_x": 0.0110453,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0022": {
    "codepoint": 34,
    "rect": [0.0361328, 0.9, 0.0799367, 1],
    "bearing_x": 0.0101563,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0023": {
    "codepoint": 35,
    "rect": [0.0800781, 0.9, 0.136193, 1],
    "bearing_x": 0.00075431,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0024": {
    "codepoint": 36,
    "rect": [0.136719, 0.9, 0.191891, 1],
    "bearing_x": 0.000942888,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0025": {
    "codepoint": 37,
    "rect": [0.192383, 0.9, 0.251973, 1],
    "bearing_x": -0.00078125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0026": {
    "codepoint": 38,
    "rect": [0.25293, 0.9, 0.306243, 1],
    "bearing_x": -2.69397e-05,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0027": {
    "codepoint": 39,
    "rect": [0.306641, 0.9, 0.338349, 1],
    "bearing_x": 0.0162177,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0028": {
    "codepoint": 40,
    "rect": [0.338867, 0.9, 0.382914, 1],
    "bearing_x": 0.00832435,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0029": {
    "codepoint": 41,
    "rect": [0.383789, 0.9, 0.427889, 1],
    "bearing_x": 0.00398707,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002a": {
    "codepoint": 42,
    "rect": [0.428711, 0.9, 0.471868, 1],
    "bearing_x": 0.00991379,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002b": {
    "codepoint": 43,
    "rect": [0.472656, 0.9, 0.522899, 1],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002c": {
    "codepoint": 44,
    "rect": [0.523438, 0.9, 0.562042, 1],
    "bearing_x": 0.00223599,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002d": {
    "codepoint": 45,
    "rect": [0.5625, 0.9, 0.601859, 1],
    "bearing_x": 0.00859375,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002e": {
    "codepoint": 46,
    "rect": [0.602539, 0.9, 0.63387, 1],
    "bearing_x": 0.0105334,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002f": {
    "codepoint": 47,
    "rect": [0.634766, 0.9, 0.692982, 1],
    "bearing_x": 0.000134698,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0030": {
    "codepoint": 48,
    "rect": [0.693359, 0.9, 0.74476, 1],
    "bearing_x": 0.0032597,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0031": {
    "codepoint": 49,
    "rect": [0.745117, 0.9, 0.795521, 1],
    "bearing_x": 0.00140086,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0032": {
    "codepoint": 50,
    "rect": [0.795898, 0.9, 0.849535, 1],
    "bearing_x": 0.00105065,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0033": {
    "codepoint": 51,
    "rect": [0.849609, 0.9, 0.901818, 1],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0034": {
    "codepoint": 52,
    "rect": [0.902344, 0.9, 0.954068, 1],
    "bearing_x": 0.00161638,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0035": {
    "codepoint": 53,
    "rect": [0, 0.8, 0.0528017, 0.9],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0036": {
    "codepoint": 54,
    "rect": [0.0537109, 0.8, 0.104519, 0.9],
    "bearing_x": 0.00396013,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0037": {
    "codepoint": 55,
    "rect": [0.105469, 0.8, 0.154203, 0.9],
    "bearing_x": 0.00773168,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0038": {
    "codepoint": 56,
    "rect": [0.154297, 0.8, 0.206479, 0.9],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0039": {
    "codepoint": 57,
    "rect": [0.207031, 0.8, 0.258163, 0.9],
    "bearing_x": 0.00317888,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u003a": {
    "codepoint": 58,
    "rect": [0.258789, 0.8, 0.294215, 0.9],
    "bearing_x": 0.0105334,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003b": {
    "codepoint": 59,
    "rect": [0.294922, 0.8, 0.33614, 0.9],
    "bearing_x": 0.00474138,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003c": {
    "codepoint": 60,
    "rect": [0.336914, 0.8, 0.387157, 0.9],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003d": {
    "codepoint": 61,
    "rect": [0.387695, 0.8, 0.437938, 0.9],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003e": {
    "codepoint": 62,
    "rect": [0.438477, 0.8, 0.488719, 0.9],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003f": {
    "codepoint": 63,
    "rect": [0.489258, 0.8, 0.5395, 0.9],
    "bearing_x": 0.00474138,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0040": {
    "codepoint": 64,
    "rect": [0.540039, 0.8, 0.59699, 0.9],
    "bearing_x": 0.000296336,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0041": {
    "codepoint": 65,
    "rect": [0.597656, 0.8, 0.654176, 0.9],
    "bearing_x": -0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0042": {
    "codepoint": 66,
    "rect": [0.654297, 0.8, 0.707745, 0.9],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0043": {
    "codepoint": 67,
    "rect": [0.708008, 0.8, 0.760944, 0.9],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0044": {
    "codepoint": 68,
    "rect": [0.761719, 0.8, 0.815275, 0.9],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0045": {
    "codepoint": 69,
    "rect": [0.81543, 0.8, 0.870683, 0.9],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0046": {
    "codepoint": 70,
    "rect": [0.871094, 0.8, 0.925593, 0.9],
    "bearing_x": 0.00239763,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0047": {
    "codepoint": 71,
    "rect": [0.925781, 0.8, 0.978421, 0.9],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0048": {
    "codepoint": 72,
    "rect": [0, 0.7, 0.0548491, 0.8],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0049": {
    "codepoint": 73,
    "rect": [0.0556641, 0.7, 0.108331, 0.8],
    "bearing_x": 0.00261315,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004a": {
    "codepoint": 74,
    "rect": [0.108398, 0.7, 0.158883, 0.8],
    "bearing_x": 0.00374461,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004b": {
    "codepoint": 75,
    "rect": [0.15918, 0.7, 0.216292, 0.8],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004c": {
    "codepoint": 76,
    "rect": [0.216797, 0.7, 0.264291, 0.8],
    "bearing_x": 0.00355603,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004d": {
    "codepoint": 77,
    "rect": [0.264648, 0.7, 0.321276, 0.8],
    "bearing_x": 0.000646552,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004e": {
    "codepoint": 78,
    "rect": [0.321289, 0.7, 0.376138, 0.8],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004f": {
    "codepoint": 79,
    "rect": [0.376953, 0.7, 0.429432, 0.8],
    "bearing_x": 0.00274784,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0050": {
    "codepoint": 80,
    "rect": [0.429688, 0.7, 0.484106, 0.8],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0051": {
    "codepoint": 81,
    "rect": [0.484375, 0.7, 0.536853, 0.8],
    "bearing_x": 0.00274784,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0052": {
    "codepoint": 82,
    "rect": [0.537109, 0.7, 0.591743, 0.8],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0053": {
    "codepoint": 83,
    "rect": [0.591797, 0.7, 0.646296, 0.8],
    "bearing_x": 0.00107759,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0054": {
    "codepoint": 84,
    "rect": [0.646484, 0.7, 0.699717, 0.8],
    "bearing_x": 0.00546875,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0055": {
    "codepoint": 85,
    "rect": [0.700195, 0.7, 0.754129, 0.8],
    "bearing_x": 0.00296336,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0056": {
    "codepoint": 86,
    "rect": [0.754883, 0.7, 0.810863, 0.8],
    "bearing_x": 0.00449892,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0057": {
    "codepoint": 87,
    "rect": [0.811523, 0.7, 0.869417, 0.8],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0058": {
    "codepoint": 88,
    "rect": [0.870117, 0.7, 0.930678, 0.8],
    "bearing_x": -0.00185884,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0059": {
    "codepoint": 89,
    "rect": [0.931641, 0.7, 0.98622, 0.8],
    "bearing_x": 0.00519935,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u005a": {
    "codepoint": 90,
    "rect": [0, 0.6, 0.0583782, 0.7],
    "bearing_x": -0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u005b": {
    "codepoint": 91,
    "rect": [0.0585938, 0.6, 0.106762, 0.7],
    "bearing_x": 0.0059806,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005c": {
    "codepoint": 92,
    "rect": [0.107422, 0.6, 0.149906, 0.7],
    "bearing_x": 0.00802802,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005d": {
    "codepoint": 93,
    "rect": [0.150391, 0.6, 0.198559, 0.7],
    "bearing_x": 0.00220905,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005e": {
    "codepoint": 94,
    "rect": [0.199219, 0.6, 0.248545, 0.7],
    "bearing_x": 0.00307112,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005f": {
    "codepoint": 95,
    "rect": [0.249023, 0.6, 0.306324, 0.7],
    "bearing_x": -0.00412177,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0060": {
    "codepoint": 96,
    "rect": [0.306641, 0.6, 0.340396, 0.7],
    "bearing_x": 0.0154903,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0061": {
    "codepoint": 97,
    "rect": [0.34082, 0.6, 0.391332, 0.7],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0062": {
    "codepoint": 98,
    "rect": [0.391602, 0.6, 0.443083, 0.7],
    "bearing_x": 0.00199353,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0063": {
    "codepoint": 99,
    "rect": [0.443359, 0.6, 0.49406, 0.7],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0064": {
    "codepoint": 100,
    "rect": [0.494141, 0.6, 0.547589, 0.7],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0065": {
    "codepoint": 101,
    "rect": [0.547852, 0.6, 0.598121, 0.7],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0066": {
    "codepoint": 102,
    "rect": [0.598633, 0.6, 0.65068, 0.7],
    "bearing_x": 0.00581897,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0067": {
    "codepoint": 103,
    "rect": [0.651367, 0.6, 0.7039, 0.7],
    "bearing_x": 0.00212823,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0068": {
    "codepoint": 104,
    "rect": [0.704102, 0.6, 0.754937, 0.7],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0069": {
    "codepoint": 105,
    "rect": [0.755859, 0.6, 0.806506, 0.7],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006a": {
    "codepoint": 106,
    "rect": [0.806641, 0.6, 0.8592, 0.7],
    "bearing_x": -0.00167026,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006b": {
    "codepoint": 107,
    "rect": [0.859375, 0.6, 0.9118, 0.7],
    "bearing_x": 0.00352909,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006c": {
    "codepoint": 108,
    "rect": [0.912109, 0.6, 0.952142, 0.7],
    "bearing_x": 0.0113955,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006d": {
    "codepoint": 109,
    "rect": [0, 0.5, 0.0552532, 0.6],
    "bearing_x": 0,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006e": {
    "codepoint": 110,
    "rect": [0.0556641, 0.5, 0.106526, 0.6],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006f": {
    "codepoint": 111,
    "rect": [0.107422, 0.5, 0.157934, 0.6],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0070": {
    "codepoint": 112,
    "rect": [0.158203, 0.5, 0.211786, 0.6],
    "bearing_x": -8.0819e-05,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0071": {
    "codepoint": 113,
    "rect": [0.211914, 0.5, 0.263477, 0.6],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0072": {
    "codepoint": 114,
    "rect": [0.263672, 0.5, 0.313025, 0.6],
    "bearing_x": 0.00509159,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0073": {
    "codepoint": 115,
    "rect": [0.313477, 0.5, 0.363396, 0.6],
    "bearing_x": 0.00296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0074": {
    "codepoint": 116,
    "rect": [0.364258, 0.5, 0.409436, 0.6],
    "bearing_x": 0.00721983,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0075": {
    "codepoint": 117,
    "rect": [0.410156, 0.5, 0.461045, 0.6],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0076": {
    "codepoint": 118,
    "rect": [0.461914, 0.5, 0.514716, 0.6],
    "bearing_x": 0.0046875,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0077": {
    "codepoint": 119,
    "rect": [0.515625, 0.5, 0.571767, 0.6],
    "bearing_x": 0.00266703,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0078": {
    "codepoint": 120,
    "rect": [0.572266, 0.5, 0.628731, 0.6],
    "bearing_x": -0.000296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0079": {
    "codepoint": 121,
    "rect": [0.628906, 0.5, 0.686907, 0.6],
    "bearing_x": -0.000457974,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u007a": {
    "codepoint": 122,
    "rect": [0.6875, 0.5, 0.740409, 0.6],
    "bearing_x": 0.00113147,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u007b": {
    "codepoint": 123,
    "rect": [0.741211, 0.5, 0.79245, 0.6],
    "bearing_x": 0.00571121,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007c": {
    "codepoint": 124,
    "rect": [0.792969, 0.5, 0.820878, 0.6],
    "bearing_x": 0.014305,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007d": {
    "codepoint": 125,
    "rect": [0.821289, 0.5, 0.872555, 0.6],
    "bearing_x": -0.000565733,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007e": {
    "codepoint": 126,
    "rect": [0.873047, 0.5, 0.924798, 0.6],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u00e0": {
    "codepoint": 224,
    "rect": [0.924805, 0.5, 0.975317, 0.6],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e1": {
    "codepoint": 225,
    "rect": [0, 0.4, 0.0506196, 0.5],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e2": {
    "codepoint": 226,
    "rect": [0.0507812, 0.4, 0.101293, 0.5],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e3": {
    "codepoint": 227,
    "rect": [0.101562, 0.4, 0.153772, 0.5],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e4": {
    "codepoint": 228,
    "rect": [0.154297, 0.4, 0.204809, 0.5],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e5": {
    "codepoint": 229,
    "rect": [0.205078, 0.4, 0.25559, 0.5],
    "bearing_x": 0.00196659,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e6": {
    "codepoint": 230,
    "rect": [0.255859, 0.4, 0.313564, 0.5],
    "bearing_x": -0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e7": {
    "codepoint": 231,
    "rect": [0.314453, 0.4, 0.365154, 0.5],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e8": {
    "codepoint": 232,
    "rect": [0.365234, 0.4, 0.415504, 0.5],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e9": {
    "codepoint": 233,
    "rect": [0.416016, 0.4, 0.466393, 0.5],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ea": {
    "codepoint": 234,
    "rect": [0.466797, 0.4, 0.517066, 0.5],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00eb": {
    "codepoint": 235,
    "rect": [0.517578, 0.4, 0.567847, 0.5],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ec": {
    "codepoint": 236,
    "rect": [0.568359, 0.4, 0.619006, 0.5],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ed": {
    "codepoint": 237,
    "rect": [0.619141, 0.4, 0.67143, 0.5],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ee": {
    "codepoint": 238,
    "rect": [0.671875, 0.4, 0.723572, 0.5],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ef": {
    "codepoint": 239,
    "rect": [0.723633, 0.4, 0.775707, 0.5],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f0": {
    "codepoint": 240,
    "rect": [0.776367, 0.4, 0.828064, 0.5],
    "bearing_x": 0.00264009,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f1": {
    "codepoint": 241,
    "rect": [0.828125, 0.4, 0.88063, 0.5],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f2": {
    "codepoint": 242,
    "rect": [0.880859, 0.4, 0.931371, 0.5],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f3": {
    "codepoint": 243,
    "rect": [0.931641, 0.4, 0.982152, 0.5],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f4": {
    "codepoint": 244,
    "rect": [0, 0.3, 0.0505119, 0.4],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f5": {
    "codepoint": 245,
    "rect": [0.0507812, 0.3, 0.102155, 0.4],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f6": {
    "codepoint": 246,
    "rect": [0.102539, 0.3, 0.153051, 0.4],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f7": {
    "codepoint": 247,
    "rect": [0.15332, 0.3, 0.203563, 0.4],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u00f8": {
    "codepoint": 248,
    "rect": [0.204102, 0.3, 0.258762, 0.4],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f9": {
    "codepoint": 249,
    "rect": [0.258789, 0.3, 0.309678, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fa": {
    "codepoint": 250,
    "rect": [0.310547, 0.3, 0.361436, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fb": {
    "codepoint": 251,
    "rect": [0.362305, 0.3, 0.413194, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fc": {
    "codepoint": 252,
    "rect": [0.414062, 0.3, 0.464952, 0.4],
    "bearing_x": 0.00363685,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u010c": {
    "codepoint": 268,
    "rect": [0.46582, 0.3, 0.518757, 0.4],
    "bearing_x": 0.003125,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u010d": {
    "codepoint": 269,
    "rect": [0.519531, 0.3, 0.570232, 0.4],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0160": {
    "codepoint": 352,
    "rect": [0.570312, 0.3, 0.624811, 0.4],
    "bearing_x": 0.00107759,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0161": {
    "codepoint": 353,
    "rect": [0.625, 0.3, 0.675889, 0.4],
    "bearing_x": 0.00296336,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u017d": {
    "codepoint": 381,
    "rect": [0.676758, 0.3, 0.735136, 0.4],
    "bearing_x": -0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u017e": {
    "codepoint": 382,
    "rect": [0.735352, 0.3, 0.788261, 0.4],
    "bearing_x": 0.00113147,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0391": {
    "codepoint": 913,
    "rect": [0.789062, 0.3, 0.845582, 0.4],
    "bearing_x": -0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0392": {
    "codepoint": 914,
    "rect": [0.845703, 0.3, 0.899151, 0.4],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0393": {
    "codepoint": 915,
    "rect": [0.899414, 0.3, 0.953913, 0.4],
    "bearing_x": 0.00320582,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0394": {
    "codepoint": 916,
    "rect": [0, 0.2, 0.0566541, 0.3],
    "bearing_x": -0.00250539,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0395": {
    "codepoint": 917,
    "rect": [0.0576172, 0.2, 0.11287, 0.3],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0396": {
    "codepoint": 918,
    "rect": [0.113281, 0.2, 0.171659, 0.3],
    "bearing_x": -0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0397": {
    "codepoint": 919,
    "rect": [0.171875, 0.2, 0.226724, 0.3],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0398": {
    "codepoint": 920,
    "rect": [0.227539, 0.2, 0.280017, 0.3],
    "bearing_x": 0.00274784,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0399": {
    "codepoint": 921,
    "rect": [0.280273, 0.2, 0.33294, 0.3],
    "bearing_x": 0.00261315,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039a": {
    "codepoint": 922,
    "rect": [0.333008, 0.2, 0.39012, 0.3],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039b": {
    "codepoint": 923,
    "rect": [0.390625, 0.2, 0.446606, 0.3],
    "bearing_x": -0.00255927,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039c": {
    "codepoint": 924,
    "rect": [0.447266, 0.2, 0.503893, 0.3],
    "bearing_x": 0.000646552,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039d": {
    "codepoint": 925,
    "rect": [0.503906, 0.2, 0.558755, 0.3],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039e": {
    "codepoint": 926,
    "rect": [0.55957, 0.2, 0.615362, 0.3],
    "bearing_x": 0.00080819,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039f": {
    "codepoint": 927,
    "rect": [0.616211, 0.2, 0.668689, 0.3],
    "bearing_x": 0.00274784,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a0": {
    "codepoint": 928,
    "rect": [0.668945, 0.2, 0.723768, 0.3],
    "bearing_x": 0.0015625,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a1": {
    "codepoint": 929,
    "rect": [0.724609, 0.2, 0.779027, 0.3],
    "bearing_x": 0.00153556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a3": {
    "codepoint": 931,
    "rect": [0.779297, 0.2, 0.837163, 0.3],
    "bearing_x": 8.0819e-05,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a4": {
    "codepoint": 932,
    "rect": [0.837891, 0.2, 0.891123, 0.3],
    "bearing_x": 0.00546875,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a5": {
    "codepoint": 933,
    "rect": [0.891602, 0.2, 0.946181, 0.3],
    "bearing_x": 0.00519935,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a6": {
    "codepoint": 934,
    "rect": [0, 0.1, 0.0567349, 0.2],
    "bearing_x": 0.00078125,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a7": {
    "codepoint": 935,
    "rect": [0.0576172, 0.1, 0.118178, 0.2],
    "bearing_x": -0.00185884,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a8": {
    "codepoint": 936,
    "rect": [0.119141, 0.1, 0.175741, 0.2],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a9": {
    "codepoint": 937,
    "rect": [0.175781, 0.1, 0.233001, 0.2],
    "bearing_x": -0.00123922,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03b1": {
    "codepoint": 945,
    "rect": [0.233398, 0.1, 0.288328, 0.2],
    "bearing_x": 0.00280172,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b2": {
    "codepoint": 946,
    "rect": [0.289062, 0.1, 0.344073, 0.2],
    "bearing_x": -0.000431034,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b3": {
    "codepoint": 947,
    "rect": [0.344727, 0.1, 0.398202, 0.2],
    "bearing_x": 0.00425647,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b4": {
    "codepoint": 948,
    "rect": [0.398438, 0.1, 0.451967, 0.2],
    "bearing_x": 0.00234375,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b5": {
    "codepoint": 949,
    "rect": [0.452148, 0.1, 0.50293, 0.2],
    "bearing_x": 0.00323276,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b6": {
    "codepoint": 950,
    "rect": [0.50293, 0.1, 0.556216, 0.2],
    "bearing_x": 0.00382543,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b7": {
    "codepoint": 951,
    "rect": [0.556641, 0.1, 0.607503, 0.2],
    "bearing_x": 0.00215517,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b8": {
    "codepoint": 952,
    "rect": [0.608398, 0.1, 0.658722, 0.2],
    "bearing_x": 0.00414871,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b9": {
    "codepoint": 953,
    "rect": [0.65918, 0.1, 0.704384, 0.2],
    "bearing_x": 0.0061153,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03ba": {
    "codepoint": 954,
    "rect": [0.705078, 0.1, 0.757503, 0.2],
    "bearing_x": 0.00352909,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bb": {
    "codepoint": 955,
    "rect": [0.757812, 0.1, 0.807974, 0.2],
    "bearing_x": 0.000242457,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bc": {
    "codepoint": 956,
    "rect": [0.808594, 0.1, 0.86312, 0.2],
    "bearing_x": -0.000862069,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bd": {
    "codepoint": 957,
    "rect": [0.863281, 0.1, 0.912392, 0.2],
    "bearing_x": 0.00530711,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03be": {
    "codepoint": 958,
    "rect": [0.913086, 0.1, 0.964056, 0.2],
    "bearing_x": 0.00398707,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bf": {
    "codepoint": 959,
    "rect": [0, 0, 0.0505119, 0.1],
    "bearing_x": 0.00301724,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c0": {
    "codepoint": 960,
    "rect": [0.0507812, 0, 0.107139, 0.1],
    "bearing_x": 0.00185884,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c1": {
    "codepoint": 961,
    "rect": [0.107422, 0, 0.16184, 0.1],
    "bearing_x": -0.000835129,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c2": {
    "codepoint": 962,
    "rect": [0.162109, 0, 0.211948, 0.1],
    "bearing_x": 0.00398707,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c3": {
    "codepoint": 963,
    "rect": [0.212891, 0, 0.270326, 0.1],
    "bearing_x": 0.00193966,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c4": {
    "codepoint": 964,
    "rect": [0.270508, 0, 0.319188, 0.1],
    "bearing_x": 0.00592672,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c5": {
    "codepoint": 965,
    "rect": [0.319336, 0, 0.369551, 0.1],
    "bearing_x": 0.00336746,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c6": {
    "codepoint": 966,
    "rect": [0.370117, 0, 0.425074, 0.1],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c7": {
    "codepoint": 967,
    "rect": [0.425781, 0, 0.485426, 0.1],
    "bearing_x": -0.0029903,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c8": {
    "codepoint": 968,
    "rect": [0.486328, 0, 0.541878, 0.1],
    "bearing_x": 0.00134698,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c9": {
    "codepoint": 969,
    "rect": [0.541992, 0, 0.596814, 0.1],
    "bearing_x": 0.000700431,
    "advance_x": 0.0331088,
    "flags": 1
  }
  },
  "kern": {
  }
}
