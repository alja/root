{
  "ix": 0.0117188, 
  "iy": 0.0136364, 
  "row_height": 0.1, 
  "aspect": 1.16364, 
  "ascent": 0.0534483, 
  "descent": 0.019279, 
  "line_gap": 0, 
  "cap_height": 0.0422884, 
  "x_height": 0.0339185, 
  "space_advance": 0.0331088, 

  "chars": { 
  "\u0021": {
    "codepoint": 33,
    "rect": [0, 0.9, 0.0384159, 1],
    "bearing_x": 0.00977909,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0022": {
    "codepoint": 34,
    "rect": [0.0390625, 0.9, 0.0845636, 1],
    "bearing_x": 0.00932112,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0023": {
    "codepoint": 35,
    "rect": [0.0849609, 0.9, 0.141534, 1],
    "bearing_x": 0.000646552,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0024": {
    "codepoint": 36,
    "rect": [0.141602, 0.9, 0.196693, 1],
    "bearing_x": 0.00107759,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0025": {
    "codepoint": 37,
    "rect": [0.197266, 0.9, 0.257664, 1],
    "bearing_x": -0.00118534,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0026": {
    "codepoint": 38,
    "rect": [0.257812, 0.9, 0.312904, 1],
    "bearing_x": -0.000511853,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0027": {
    "codepoint": 39,
    "rect": [0.313477, 0.9, 0.346639, 1],
    "bearing_x": 0.0154634,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0028": {
    "codepoint": 40,
    "rect": [0.34668, 0.9, 0.391669, 1],
    "bearing_x": 0.0082166,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0029": {
    "codepoint": 41,
    "rect": [0.392578, 0.9, 0.437594, 1],
    "bearing_x": 0.00320582,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002a": {
    "codepoint": 42,
    "rect": [0.438477, 0.9, 0.483169, 1],
    "bearing_x": 0.00894397,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002b": {
    "codepoint": 43,
    "rect": [0.483398, 0.9, 0.534503, 1],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002c": {
    "codepoint": 44,
    "rect": [0.535156, 0.9, 0.575108, 1],
    "bearing_x": 0.00220905,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002d": {
    "codepoint": 45,
    "rect": [0.575195, 0.9, 0.615524, 1],
    "bearing_x": 0.00805496,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002e": {
    "codepoint": 46,
    "rect": [0.616211, 0.9, 0.649023, 1],
    "bearing_x": 0.00983297,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u002f": {
    "codepoint": 47,
    "rect": [0.649414, 0.9, 0.708978, 1],
    "bearing_x": -0.000538793,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0030": {
    "codepoint": 48,
    "rect": [0.708984, 0.9, 0.760816, 1],
    "bearing_x": 0.00307112,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0031": {
    "codepoint": 49,
    "rect": [0.761719, 0.9, 0.813012, 1],
    "bearing_x": 0.00118534,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0032": {
    "codepoint": 50,
    "rect": [0.813477, 0.9, 0.868326, 1],
    "bearing_x": 0.000484914,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0033": {
    "codepoint": 51,
    "rect": [0.869141, 0.9, 0.922966, 1],
    "bearing_x": 0.00158944,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0034": {
    "codepoint": 52,
    "rect": [0.923828, 0.9, 0.977896, 1],
    "bearing_x": 0.000592672,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0035": {
    "codepoint": 53,
    "rect": [0, 0.8, 0.0539063, 0.9],
    "bearing_x": 0.00180496,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0036": {
    "codepoint": 54,
    "rect": [0.0546875, 0.8, 0.106358, 0.9],
    "bearing_x": 0.00342134,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0037": {
    "codepoint": 55,
    "rect": [0.106445, 0.8, 0.157307, 0.9],
    "bearing_x": 0.00622306,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0038": {
    "codepoint": 56,
    "rect": [0.158203, 0.8, 0.211678, 0.9],
    "bearing_x": 0.00185884,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0039": {
    "codepoint": 57,
    "rect": [0.211914, 0.8, 0.26415, 0.9],
    "bearing_x": 0.00253233,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u003a": {
    "codepoint": 58,
    "rect": [0.264648, 0.8, 0.301556, 0.9],
    "bearing_x": 0.00983297,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003b": {
    "codepoint": 59,
    "rect": [0.301758, 0.8, 0.3447, 0.9],
    "bearing_x": 0.00404095,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003c": {
    "codepoint": 60,
    "rect": [0.344727, 0.8, 0.395831, 0.9],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003d": {
    "codepoint": 61,
    "rect": [0.396484, 0.8, 0.447589, 0.9],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003e": {
    "codepoint": 62,
    "rect": [0.448242, 0.8, 0.499347, 0.9],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u003f": {
    "codepoint": 63,
    "rect": [0.5, 0.8, 0.551859, 0.9],
    "bearing_x": 0.00409483,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0040": {
    "codepoint": 64,
    "rect": [0.552734, 0.8, 0.609685, 0.9],
    "bearing_x": 0.000296336,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0041": {
    "codepoint": 65,
    "rect": [0.610352, 0.8, 0.666898, 0.9],
    "bearing_x": -0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0042": {
    "codepoint": 66,
    "rect": [0.666992, 0.8, 0.722003, 0.9],
    "bearing_x": 0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0043": {
    "codepoint": 67,
    "rect": [0.722656, 0.8, 0.776994, 0.9],
    "bearing_x": 0.00223599,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0044": {
    "codepoint": 68,
    "rect": [0.777344, 0.8, 0.832274, 0.9],
    "bearing_x": 0.00080819,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0045": {
    "codepoint": 69,
    "rect": [0.833008, 0.8, 0.889581, 0.9],
    "bearing_x": 0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0046": {
    "codepoint": 70,
    "rect": [0.889648, 0.8, 0.94544, 0.9],
    "bearing_x": 0.00167026,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0047": {
    "codepoint": 71,
    "rect": [0.946289, 0.8, 0.999468, 0.9],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0048": {
    "codepoint": 72,
    "rect": [0, 0.7, 0.0561692, 0.8],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0049": {
    "codepoint": 73,
    "rect": [0.0566406, 0.7, 0.111813, 0.8],
    "bearing_x": 0.00140086,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004a": {
    "codepoint": 74,
    "rect": [0.112305, 0.7, 0.16543, 0.8],
    "bearing_x": 0.00199353,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004b": {
    "codepoint": 75,
    "rect": [0.166016, 0.7, 0.225444, 0.8],
    "bearing_x": 0.000835129,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004c": {
    "codepoint": 76,
    "rect": [0.225586, 0.7, 0.274751, 0.8],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004d": {
    "codepoint": 77,
    "rect": [0.275391, 0.7, 0.333661, 0.8],
    "bearing_x": -0.000161638,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004e": {
    "codepoint": 78,
    "rect": [0.333984, 0.7, 0.390315, 0.8],
    "bearing_x": 0.00080819,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u004f": {
    "codepoint": 79,
    "rect": [0.390625, 0.7, 0.444639, 0.8],
    "bearing_x": 0.00199353,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0050": {
    "codepoint": 80,
    "rect": [0.445312, 0.7, 0.50097, 0.8],
    "bearing_x": 0.000835129,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0051": {
    "codepoint": 81,
    "rect": [0.500977, 0.7, 0.554991, 0.8],
    "bearing_x": 0.00199353,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0052": {
    "codepoint": 82,
    "rect": [0.555664, 0.7, 0.611806, 0.8],
    "bearing_x": 0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0053": {
    "codepoint": 83,
    "rect": [0.612305, 0.7, 0.668474, 0.8],
    "bearing_x": 0.000107759,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0054": {
    "codepoint": 84,
    "rect": [0.668945, 0.7, 0.72339, 0.8],
    "bearing_x": 0.0046875,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0055": {
    "codepoint": 85,
    "rect": [0.723633, 0.7, 0.778105, 0.8],
    "bearing_x": 0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0056": {
    "codepoint": 86,
    "rect": [0.77832, 0.7, 0.834732, 0.8],
    "bearing_x": 0.00431034,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0057": {
    "codepoint": 87,
    "rect": [0.834961, 0.7, 0.892854, 0.8],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0058": {
    "codepoint": 88,
    "rect": [0.893555, 0.7, 0.956055, 0.8],
    "bearing_x": -0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0059": {
    "codepoint": 89,
    "rect": [0, 0.6, 0.0563578, 0.7],
    "bearing_x": 0.00431034,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u005a": {
    "codepoint": 90,
    "rect": [0.0566406, 0.6, 0.114345, 0.7],
    "bearing_x": -0.000484914,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u005b": {
    "codepoint": 91,
    "rect": [0.115234, 0.6, 0.164884, 0.7],
    "bearing_x": 0.00498384,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005c": {
    "codepoint": 92,
    "rect": [0.165039, 0.6, 0.20887, 0.7],
    "bearing_x": 0.00738147,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005d": {
    "codepoint": 93,
    "rect": [0.208984, 0.6, 0.258634, 0.7],
    "bearing_x": 0.00177802,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005e": {
    "codepoint": 94,
    "rect": [0.258789, 0.6, 0.312022, 0.7],
    "bearing_x": 0.00107759,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u005f": {
    "codepoint": 95,
    "rect": [0.3125, 0.6, 0.369801, 0.7],
    "bearing_x": -0.00412177,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0060": {
    "codepoint": 96,
    "rect": [0.370117, 0.6, 0.406243, 0.7],
    "bearing_x": 0.0139278,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u0061": {
    "codepoint": 97,
    "rect": [0.40625, 0.6, 0.458082, 0.7],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0062": {
    "codepoint": 98,
    "rect": [0.458984, 0.6, 0.512567, 0.7],
    "bearing_x": 0.000942888,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0063": {
    "codepoint": 99,
    "rect": [0.512695, 0.6, 0.564339, 0.7],
    "bearing_x": 0.00250539,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0064": {
    "codepoint": 100,
    "rect": [0.564453, 0.6, 0.619868, 0.7],
    "bearing_x": 0.00207435,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0065": {
    "codepoint": 101,
    "rect": [0.620117, 0.6, 0.672003, 0.7],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0066": {
    "codepoint": 102,
    "rect": [0.672852, 0.6, 0.726488, 0.7],
    "bearing_x": 0.00498384,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0067": {
    "codepoint": 103,
    "rect": [0.726562, 0.6, 0.78187, 0.7],
    "bearing_x": 0.000969828,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0068": {
    "codepoint": 104,
    "rect": [0.782227, 0.6, 0.835567, 0.7],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0069": {
    "codepoint": 105,
    "rect": [0.835938, 0.6, 0.888093, 0.7],
    "bearing_x": 0.000350216,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006a": {
    "codepoint": 106,
    "rect": [0.888672, 0.6, 0.941985, 0.7],
    "bearing_x": -0.00167026,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006b": {
    "codepoint": 107,
    "rect": [0.942383, 0.6, 0.997582, 0.7],
    "bearing_x": 0.0018319,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006c": {
    "codepoint": 108,
    "rect": [0, 0.5, 0.0425377, 0.6],
    "bearing_x": 0.00996767,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006d": {
    "codepoint": 109,
    "rect": [0.0429688, 0.5, 0.0998384, 0.6],
    "bearing_x": -0.00080819,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006e": {
    "codepoint": 110,
    "rect": [0.100586, 0.5, 0.153926, 0.6],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u006f": {
    "codepoint": 111,
    "rect": [0.154297, 0.5, 0.206829, 0.6],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0070": {
    "codepoint": 112,
    "rect": [0.207031, 0.5, 0.262581, 0.6],
    "bearing_x": -0.00107759,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0071": {
    "codepoint": 113,
    "rect": [0.262695, 0.5, 0.316251, 0.6],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0072": {
    "codepoint": 114,
    "rect": [0.316406, 0.5, 0.367915, 0.6],
    "bearing_x": 0.00390625,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0073": {
    "codepoint": 115,
    "rect": [0.368164, 0.5, 0.420265, 0.6],
    "bearing_x": 0.0018319,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0074": {
    "codepoint": 116,
    "rect": [0.420898, 0.5, 0.467693, 0.6],
    "bearing_x": 0.00616918,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0075": {
    "codepoint": 117,
    "rect": [0.467773, 0.5, 0.520548, 0.6],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0076": {
    "codepoint": 118,
    "rect": [0.521484, 0.5, 0.576226, 0.6],
    "bearing_x": 0.00366379,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0077": {
    "codepoint": 119,
    "rect": [0.577148, 0.5, 0.633829, 0.6],
    "bearing_x": 0.00239763,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0078": {
    "codepoint": 120,
    "rect": [0.634766, 0.5, 0.69371, 0.6],
    "bearing_x": -0.00150862,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0079": {
    "codepoint": 121,
    "rect": [0.694336, 0.5, 0.753792, 0.6],
    "bearing_x": -0.00113147,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u007a": {
    "codepoint": 122,
    "rect": [0.753906, 0.5, 0.806977, 0.6],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u007b": {
    "codepoint": 123,
    "rect": [0.807617, 0.5, 0.859476, 0.6],
    "bearing_x": 0.00466056,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007c": {
    "codepoint": 124,
    "rect": [0.860352, 0.5, 0.890847, 0.6],
    "bearing_x": 0.0130119,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007d": {
    "codepoint": 125,
    "rect": [0.891602, 0.5, 0.943487, 0.6],
    "bearing_x": -0.000107759,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u007e": {
    "codepoint": 126,
    "rect": [0.944336, 0.5, 0.997138, 0.6],
    "bearing_x": 0.00258621,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u00e0": {
    "codepoint": 224,
    "rect": [0, 0.4, 0.0518319, 0.5],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e1": {
    "codepoint": 225,
    "rect": [0.0527344, 0.4, 0.105294, 0.5],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e2": {
    "codepoint": 226,
    "rect": [0.105469, 0.4, 0.157301, 0.5],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e3": {
    "codepoint": 227,
    "rect": [0.158203, 0.4, 0.211948, 0.5],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e4": {
    "codepoint": 228,
    "rect": [0.212891, 0.4, 0.264723, 0.5],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e5": {
    "codepoint": 229,
    "rect": [0.265625, 0.4, 0.317457, 0.5],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e6": {
    "codepoint": 230,
    "rect": [0.318359, 0.4, 0.37601, 0.5],
    "bearing_x": -0.000969828,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e7": {
    "codepoint": 231,
    "rect": [0.376953, 0.4, 0.428596, 0.5],
    "bearing_x": 0.00250539,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e8": {
    "codepoint": 232,
    "rect": [0.428711, 0.4, 0.480597, 0.5],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00e9": {
    "codepoint": 233,
    "rect": [0.481445, 0.4, 0.534032, 0.5],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ea": {
    "codepoint": 234,
    "rect": [0.53418, 0.4, 0.586065, 0.5],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00eb": {
    "codepoint": 235,
    "rect": [0.586914, 0.4, 0.6388, 0.5],
    "bearing_x": 0.00226293,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ec": {
    "codepoint": 236,
    "rect": [0.639648, 0.4, 0.691804, 0.5],
    "bearing_x": 0.000350216,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ed": {
    "codepoint": 237,
    "rect": [0.692383, 0.4, 0.746693, 0.5],
    "bearing_x": 0.000350216,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ee": {
    "codepoint": 238,
    "rect": [0.74707, 0.4, 0.800411, 0.5],
    "bearing_x": 0.000350216,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00ef": {
    "codepoint": 239,
    "rect": [0.800781, 0.4, 0.855011, 0.5],
    "bearing_x": 0.000350216,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f0": {
    "codepoint": 240,
    "rect": [0.855469, 0.4, 0.908594, 0.5],
    "bearing_x": 0.00158944,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f1": {
    "codepoint": 241,
    "rect": [0.90918, 0.4, 0.963759, 0.5],
    "bearing_x": 0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f2": {
    "codepoint": 242,
    "rect": [0, 0.3, 0.0525323, 0.4],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f3": {
    "codepoint": 243,
    "rect": [0.0527344, 0.3, 0.105267, 0.4],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f4": {
    "codepoint": 244,
    "rect": [0.105469, 0.3, 0.158001, 0.4],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f5": {
    "codepoint": 245,
    "rect": [0.158203, 0.3, 0.21149, 0.4],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f6": {
    "codepoint": 246,
    "rect": [0.211914, 0.3, 0.264446, 0.4],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f7": {
    "codepoint": 247,
    "rect": [0.264648, 0.3, 0.315753, 0.4],
    "bearing_x": 0.00272091,
    "advance_x": 0.0331088,
    "flags": 4
  },
  "\u00f8": {
    "codepoint": 248,
    "rect": [0.316406, 0.3, 0.372414, 0.4],
    "bearing_x": 0.000188578,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00f9": {
    "codepoint": 249,
    "rect": [0.373047, 0.3, 0.425822, 0.4],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fa": {
    "codepoint": 250,
    "rect": [0.426758, 0.3, 0.479533, 0.4],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fb": {
    "codepoint": 251,
    "rect": [0.480469, 0.3, 0.533244, 0.4],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u00fc": {
    "codepoint": 252,
    "rect": [0.53418, 0.3, 0.586954, 0.4],
    "bearing_x": 0.00247845,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u010c": {
    "codepoint": 268,
    "rect": [0.587891, 0.3, 0.642228, 0.4],
    "bearing_x": 0.00223599,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u010d": {
    "codepoint": 269,
    "rect": [0.642578, 0.3, 0.694706, 0.4],
    "bearing_x": 0.00250539,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0160": {
    "codepoint": 352,
    "rect": [0.695312, 0.3, 0.751482, 0.4],
    "bearing_x": 0.000107759,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0161": {
    "codepoint": 353,
    "rect": [0.751953, 0.3, 0.804997, 0.4],
    "bearing_x": 0.0018319,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u017d": {
    "codepoint": 381,
    "rect": [0.805664, 0.3, 0.863369, 0.4],
    "bearing_x": -0.000484914,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u017e": {
    "codepoint": 382,
    "rect": [0.864258, 0.3, 0.918137, 0.4],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u0391": {
    "codepoint": 913,
    "rect": [0.918945, 0.3, 0.975492, 0.4],
    "bearing_x": -0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0392": {
    "codepoint": 914,
    "rect": [0, 0.2, 0.0550108, 0.3],
    "bearing_x": 0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0393": {
    "codepoint": 915,
    "rect": [0.0556641, 0.2, 0.11221, 0.3],
    "bearing_x": 0.00193966,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0394": {
    "codepoint": 916,
    "rect": [0.112305, 0.2, 0.169093, 0.3],
    "bearing_x": -0.00234375,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0395": {
    "codepoint": 917,
    "rect": [0.169922, 0.2, 0.226495, 0.3],
    "bearing_x": 0.000862069,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0396": {
    "codepoint": 918,
    "rect": [0.226562, 0.2, 0.284267, 0.3],
    "bearing_x": -0.000484914,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0397": {
    "codepoint": 919,
    "rect": [0.285156, 0.2, 0.341325, 0.3],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0398": {
    "codepoint": 920,
    "rect": [0.341797, 0.2, 0.396296, 0.3],
    "bearing_x": 0.00175108,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u0399": {
    "codepoint": 921,
    "rect": [0.396484, 0.2, 0.451657, 0.3],
    "bearing_x": 0.00140086,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039a": {
    "codepoint": 922,
    "rect": [0.452148, 0.2, 0.511577, 0.3],
    "bearing_x": 0.000835129,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039b": {
    "codepoint": 923,
    "rect": [0.511719, 0.2, 0.567187, 0.3],
    "bearing_x": -0.00228987,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039c": {
    "codepoint": 924,
    "rect": [0.567383, 0.2, 0.625653, 0.3],
    "bearing_x": -0.000161638,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039d": {
    "codepoint": 925,
    "rect": [0.625977, 0.2, 0.682307, 0.3],
    "bearing_x": 0.00080819,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039e": {
    "codepoint": 926,
    "rect": [0.682617, 0.2, 0.739487, 0.3],
    "bearing_x": 0.000269397,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u039f": {
    "codepoint": 927,
    "rect": [0.740234, 0.2, 0.794248, 0.3],
    "bearing_x": 0.00199353,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a0": {
    "codepoint": 928,
    "rect": [0.794922, 0.2, 0.851091, 0.3],
    "bearing_x": 0.000889009,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a1": {
    "codepoint": 929,
    "rect": [0.851562, 0.2, 0.90722, 0.3],
    "bearing_x": 0.000835129,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a3": {
    "codepoint": 931,
    "rect": [0.907227, 0.2, 0.964554, 0.3],
    "bearing_x": -0.000134698,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a4": {
    "codepoint": 932,
    "rect": [0, 0.1, 0.054445, 0.2],
    "bearing_x": 0.0046875,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a5": {
    "codepoint": 933,
    "rect": [0.0546875, 0.1, 0.111045, 0.2],
    "bearing_x": 0.00431034,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a6": {
    "codepoint": 934,
    "rect": [0.111328, 0.1, 0.16809, 0.2],
    "bearing_x": 0.00078125,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a7": {
    "codepoint": 935,
    "rect": [0.168945, 0.1, 0.231445, 0.2],
    "bearing_x": -0.00282866,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a8": {
    "codepoint": 936,
    "rect": [0.231445, 0.1, 0.288288, 0.2],
    "bearing_x": 0.00269397,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03a9": {
    "codepoint": 937,
    "rect": [0.289062, 0.1, 0.346956, 0.2],
    "bearing_x": -0.00148168,
    "advance_x": 0.0331088,
    "flags": 2
  },
  "\u03b1": {
    "codepoint": 945,
    "rect": [0.347656, 0.1, 0.405738, 0.2],
    "bearing_x": 0.00126616,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b2": {
    "codepoint": 946,
    "rect": [0.40625, 0.1, 0.463147, 0.2],
    "bearing_x": -0.00123922,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b3": {
    "codepoint": 947,
    "rect": [0.463867, 0.1, 0.518366, 0.2],
    "bearing_x": 0.00379849,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b4": {
    "codepoint": 948,
    "rect": [0.518555, 0.1, 0.574697, 0.2],
    "bearing_x": 0.00137392,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b5": {
    "codepoint": 949,
    "rect": [0.575195, 0.1, 0.628563, 0.2],
    "bearing_x": 0.00210129,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b6": {
    "codepoint": 950,
    "rect": [0.628906, 0.1, 0.683378, 0.2],
    "bearing_x": 0.00342134,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b7": {
    "codepoint": 951,
    "rect": [0.683594, 0.1, 0.737096, 0.2],
    "bearing_x": 0.00113147,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b8": {
    "codepoint": 952,
    "rect": [0.737305, 0.1, 0.788544, 0.2],
    "bearing_x": 0.00366379,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03b9": {
    "codepoint": 953,
    "rect": [0.789062, 0.1, 0.836638, 0.2],
    "bearing_x": 0.00503772,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03ba": {
    "codepoint": 954,
    "rect": [0.836914, 0.1, 0.892113, 0.2],
    "bearing_x": 0.0018319,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bb": {
    "codepoint": 955,
    "rect": [0.892578, 0.1, 0.945622, 0.2],
    "bearing_x": -0.00102371,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bc": {
    "codepoint": 956,
    "rect": [0, 0, 0.0573276, 0.1],
    "bearing_x": -0.00145474,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bd": {
    "codepoint": 957,
    "rect": [0.0576172, 0, 0.108749, 0.1],
    "bearing_x": 0.00390625,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03be": {
    "codepoint": 958,
    "rect": [0.109375, 0, 0.162231, 0.1],
    "bearing_x": 0.00304418,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03bf": {
    "codepoint": 959,
    "rect": [0.163086, 0, 0.215618, 0.1],
    "bearing_x": 0.00204741,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c0": {
    "codepoint": 960,
    "rect": [0.21582, 0, 0.273471, 0.1],
    "bearing_x": 0.000619612,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c1": {
    "codepoint": 961,
    "rect": [0.274414, 0, 0.330206, 0.1],
    "bearing_x": -0.00161638,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c2": {
    "codepoint": 962,
    "rect": [0.331055, 0, 0.382563, 0.1],
    "bearing_x": 0.0033944,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c3": {
    "codepoint": 963,
    "rect": [0.382812, 0, 0.440329, 0.1],
    "bearing_x": 0.00164332,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c4": {
    "codepoint": 964,
    "rect": [0.44043, 0, 0.49043, 0.1],
    "bearing_x": 0.00509159,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c5": {
    "codepoint": 965,
    "rect": [0.491211, 0, 0.542746, 0.1],
    "bearing_x": 0.0028556,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c6": {
    "codepoint": 966,
    "rect": [0.542969, 0, 0.598384, 0.1],
    "bearing_x": 0.000646552,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c7": {
    "codepoint": 967,
    "rect": [0.598633, 0, 0.660055, 0.1],
    "bearing_x": -0.00393319,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c8": {
    "codepoint": 968,
    "rect": [0.660156, 0, 0.716487, 0.1],
    "bearing_x": 0.00107759,
    "advance_x": 0.0331088,
    "flags": 1
  },
  "\u03c9": {
    "codepoint": 969,
    "rect": [0.716797, 0, 0.771969, 0.1],
    "bearing_x": 0.000538793,
    "advance_x": 0.0331088,
    "flags": 1
  }
  },
  "kern": {
  }
}
